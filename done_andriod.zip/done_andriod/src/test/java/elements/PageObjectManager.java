package elements;


public class PageObjectManager {
	private CreateTaskElement createTaskElement;
	
			
		public CreateTaskElement getcreateTaskElement() {

			return (createTaskElement == null) ? createTaskElement = new CreateTaskElement() : createTaskElement;

		}
}
