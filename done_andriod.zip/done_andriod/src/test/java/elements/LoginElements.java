package elements;

import org.openqa.selenium.support.PageFactory;

import base.BaseClass;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginElements extends BaseClass {	
	
	public LoginElements(AppiumDriver<MobileElement> driver) {
		
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
	}
	
	// to find the elements
	
	@AndroidFindBy(xpath = "/app")
	private MobileElement loginButton;


	public MobileElement getLoginButton() {
		return loginButton;
	}

}
