package elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class CreateTaskElement extends BaseClass {
	
	
public CreateTaskElement() {
		
		PageFactory.initElements(driver,this);
	}

	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"NewsLayout\"])[3]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ImageView")
	private WebElement actionButton;
	
	@FindBy(xpath = "//android.widget.ImageView[@content-desc='CreateNewTask']")
	private WebElement createNewTask;
	
	@FindBy(xpath = "//android.widget.EditText[@content-desc='RemarkEditor']")
	private WebElement  actionTextArea;
	
	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"CircularImageView\"])[1]/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.View")
	private WebElement assginee;
	
	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc='TagView'])[3]/android.widget.FrameLayout")
	private WebElement category;
	
	@FindBy(xpath = "(//android.widget.Button[@content-desc=\"CreateButton\"])")
	private WebElement CreateTeskButton;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"CreateAITaskPage\"]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]")
	private WebElement message;
	
	@FindBy(xpath = "//android.widget.Button[@content-desc='CreateButton']")
	private WebElement okButton;
	
	@FindBy(xpath = "(//android.widget.FrameLayout[@content-desc=\"mainFrameView\"])[1]/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView")
	 private WebElement taskCheck;
	
	@FindBy(xpath="//android.view.ViewGroup[@content-desc=\"CheckBox\"]/android.widget.ImageView")
	private WebElement selectPriority;
	
	@FindBy(xpath="//android.view.View[@content-desc=\"10 March 2023\"]")
	private WebElement closureDate;
	
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"DatePicker\"]")
	private WebElement datePicker;
	
	@FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.Button[2]")
	private WebElement okButtonCalender;
	
	
	
	public WebElement getActionButton() {
		return actionButton;
	}

	public WebElement getCreateNewTask() {
		return createNewTask;
	}

	public WebElement getActionTextArea() {
		return actionTextArea;
	}

	public WebElement getAssginee() {
		return assginee;
	}

	public WebElement getCategory() {
		return category;
	}

	
	public WebElement getCreateTeskButton() {
		return CreateTeskButton;
	}


	public WebElement getMessage() {
		return message;
	}

	public WebElement getOkButton() {
		return okButton;
	}

	public WebElement getTaskCheck() {
		return taskCheck;
	}

	public WebElement getSelectPriority() {
		return selectPriority;
	}

	
	public WebElement getClosureDate() {
		return closureDate;
	}

	public WebElement getDatePicker() {
		return datePicker;
	}

	public WebElement getOkButtonCalender() {
		return okButtonCalender;
	}
	
	
}
