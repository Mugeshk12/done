//package elements;
//cucumber.object-factory=your.package.name.MyObjectFactory
//import org.picocontainer.DefaultPicoContainer;
//import org.picocontainer.MutablePicoContainer;
//import org.picocontainer.PicoBuilder;
//
//import io.cucumber.core.backend.ObjectFactory;
//import io.cucumber.core.exception.CucumberException;
//import io.cucumber.junit.Cucumber;
//
//public class ServiceFactor implements ObjectFactory{
//	private final MutablePicoContainer container;
//	public ServiceFactor() {
//		this.container =new PicoBuilder().withCaching().build();
//		container.addComponent(CreateTaskElement.class);
//		
//	}
//	@Override
//	public boolean addClass(Class<?> glueClass) {
//		// TODO Auto-generated method stub
//		return true;
//	}
//	@Override
//	public <T> T getInstance(final Class<T> glueClass) {
//
//		try {
//			return container.getComponent(glueClass);
//		} catch (final Throwable t) {
//          throw new CucumberException(t);
//		}
//	}
//	@Override
//	public void start() {
//		// TODO Auto-generated method stub
//		
//	}
//	@Override
//	public void stop() {
//    container.stop();		
//	}
//	
//
//	
//
//}
