//package base;
//
//import java.net.MalformedURLException;
//import java.net.URL;
//
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.remote.DesiredCapabilities;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import io.appium.java_client.AppiumDriver;
//import io.appium.java_client.MobileElement;
//import io.appium.java_client.android.AndroidDriver;
//
//public class DriverCreation  {
//
//	public static AppiumDriver<MobileElement> driver;
//	public static WebDriverWait wait;
//	public static WebElement ele;
//	
////	public  void driverCreation() {
////		
////		DesiredCapabilities capabilities = new DesiredCapabilities();
////
//////		capabilities.setCapability("udid", "RZ8M42NV31R");
//////		capabilities.setCapability("deviceName", "Mugesh");
//////		capabilities.setCapability("platformName", "Android");
//////		capabilities.setCapability("platformVersion", "11");
////		
////		capabilities.setCapability("platformName", "Android");
////		capabilities.setCapability("deviceName", "Android Emulator");
////		
////		
////		capabilities.setCapability("noReset", "true");
////		capabilities.setCapability("newCommandTimeout", "300");
////		capabilities.setCapability("appPackage", "com.hcl.todo");
////		capabilities.setCapability("appActivity", "crc64f3cd404206cf221c.MainActivity");
////
////		URL url = null;
////
////		try {
////			url = new URL("http://127.0.0.1:4723/wd/hub");
////		} catch (MalformedURLException e) {
////			e.getMessage();
////		}
////
////		driver = new AndroidDriver<MobileElement>(url, capabilities);
////		System.out.println("\nApplication Start Running");
////		wait = new WebDriverWait(driver, 20);
//
//	
//	
////	public static AppiumDriver<MobileElement> getDriver() {
////		if (driver == null) {
////			try {
////				DesiredCapabilities capabilities = new DesiredCapabilities();
////				//capabilities.setCapability("deviceName", "Mugesh");
////				//capabilities.setCapability("platformName", "Android");
////				//capabilities.setCapability("platformVersion", "11");
////
////				capabilities.setCapability("platformName", "Android");
////				capabilities.setCapability("deviceName", "Android Emulator");
////				capabilities.setCapability("noReset", "true");
////				capabilities.setCapability("newCommandTimeout", "300");
////				capabilities.setCapability("appPackage", "com.hcl.todo");
////				capabilities.setCapability("appActivity", "crc64f3cd404206cf221c.MainActivity");			
////				
////				
////              				
////				driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
////			} catch (Exception e) {
////				System.out.println(e.getMessage());
////			}
////		}
////		return driver;
////	}
////	public static void closeDriver() {
////		if(getDriver() != null) {
////			getDriver().close();
////			driver = null;
////		}
////	}
////	public static void quitDriver() {
////		if (getDriver() != null){
////			getDriver().quit();		
////			driver = null;
////		}
////	}
//		
//		
//		
//}
////}