package base;

import java.io.IOException;
import java.util.Properties;

public class ConfigurationProperties {
	public static Properties properties;

	public String getUdId() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("udid");
	}

	public String getPlatformName() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("platformName");
	}

	public String getPlatformVersion() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("platformVersion");
	}

	public String getDeviceName() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("deviceName");
	}

	public String getAppPackage() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("appPackage");
	}

	public String getAppActivity() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("appActivity");
	}

	public String getDeviceNameForEmulator() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("deviceNameForEmulator");
	}

	public String getGnoReset() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("gnoReset");
	}

	public String getNewCommandTimeout() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("newCommandTimeout");
	}

	public String getTestDevice() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties.getProperty("testDevice");
	}

}
