package base;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class BaseClass {
	public static AppiumDriver<MobileElement> driver;
	public static WebDriverWait wait;
	public static WebElement element;
	public final int CONSTANT_WAIT_TIME = 60;
		
	public  void driverCreation() {
		
		DesiredCapabilities capabilities = new DesiredCapabilities();

//		capabilities.setCapability("udid", "RZ8M42NV31R");
//		capabilities.setCapability("deviceName", "Mugesh");
//		capabilities.setCapability("platformName", "Android");
//		capabilities.setCapability("platformVersion", "11");
		
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("deviceName", "Android Emulator");
		capabilities.setCapability("noReset", "true");
		capabilities.setCapability("newCommandTimeout", "300");
		capabilities.setCapability("appPackage", "com.hcl.todo");
		capabilities.setCapability("appActivity", "crc64f3cd404206cf221c.MainActivity");

		URL url = null;

		try {
			url = new URL("http://127.0.0.1:4723/wd/hub");
		} catch (MalformedURLException e) {
			e.getMessage();
		}

		driver = new AndroidDriver<MobileElement>(url, capabilities);
		System.out.println("Application Start Running");
		wait = new WebDriverWait(driver, CONSTANT_WAIT_TIME);
	
	}
	
	
//	public static TouchAction touchAction = new TouchAction (getDriver());
	
	
	public static void implicityWait(int time ) {
		driver.manage().timeouts().implicitlyWait(time,TimeUnit.SECONDS);
	}

	public static WebElement waitForElementToVisible(WebElement element) {

		return  wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	
	public static WebElement waitForElementClickable(WebElement element) {

		return  wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	

	public static void clickElement(WebElement element) {
		waitForElementClickable(element).click();
	}

	public static void sendText(WebElement element, String text) {
		waitForElementClickable(element).sendKeys(text);
	}

	public static String getText(WebElement element) {
		waitForElementClickable(element);
		return waitForElementClickable(element).getText();
	}
	

	// need improve count size

//	public static int getSize(MobileElement element) {
//		return waitForElement(element).size();
//		
//	}

	// need improvement print the element
//	public static String getListOfElements(By element){
//		waitForElement(element);
//		return driver.findElements(element);		
//	}
	


//	public static void tapOnElement(MobileElement element) {
//		touchAction.tap(PointOption.point(element.getCenter())).perform();
//	}
//		
//	
//	public static void swipeUp() {
//		Dimension size =getDriver().manage().window().getSize();
//		int startY = (int)(size.height * 0.9);
//		int endY = (int)(size.height * 0.2);
//		int startX = size.width/3;
//		touchAction.press(PointOption.point(startX,startY)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
//		.moveTo(PointOption.point(startX,endY)).release().perform();			
//	}
//	
//	public static void swipeDown() {
//		Dimension size =getDriver().manage().window().getSize();
//		int startY = (int)(size.height * 0.3);
//		int endY = (int)(size.height * 0.9);
//		int startX = size.width/2;
//		touchAction.press(PointOption.point(startX,startY)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
//		.moveTo(PointOption.point(startX,endY)).release().perform();			
//	}
//	
//	public static void swipeLeft() {
//		Dimension size =getDriver().manage().window().getSize();
//		int startX = (int)(size.height * 0.9);
//		int endX = (int)(size.height * 0.2);
//		int startY = size.width/2;
//		touchAction.press(PointOption.point(startX,startY)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
//		.moveTo(PointOption.point(endX,startY)).release().perform();			
//	}
//	
//	public static void swipeRight() {
//		Dimension size =getDriver().manage().window().getSize();
//		int startX = (int)(size.height * 0.9);
//		int endX = (int)(size.height * 0.3);
//		int startY = size.width/2;
//		touchAction.press(PointOption.point(startX,startY)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
//		.moveTo(PointOption.point(endX,startY)).release().perform();			
//	}

}
