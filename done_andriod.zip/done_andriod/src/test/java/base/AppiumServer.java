package base;
//
//import io.appium.java_client.service.local.AppiumDriverLocalService;
//import io.appium.java_client.service.local.AppiumServiceBuilder;
//import io.appium.java_client.service.local.flags.GeneralServerFlag;
//
// not fully implement pre-stage
//
//public class AppiumServer {
//
//	public static AppiumDriverLocalService appiumService;
//	public static AppiumServiceBuilder serviceBuilder;
//
//	public AppiumServer() {
//		serviceBuilder = new AppiumServiceBuilder().withIPAddress("127.0.0.1")
//				.usingAnyFreePort().withArgument(GeneralServerFlag.SESSION_OVERRIDE).withArgument(GeneralServerFlag.LOG_LEVEL,"error");
//		appiumService = AppiumDriverLocalService.buildService(serviceBuilder);
//	}
//
//	public void startServer() {
//		if (!appiumService.isRunning()) {
//			appiumService.start();
//			System.out.println("start");
//		}
//	}
//
//	public void stopServer() {
//		if (appiumService.isRunning()) {
//			appiumService.stop();
//		}
//	}
//
//	public String getServerURL() {
//		if (appiumService == null || !appiumService.isRunning()) {
//			return null;
//		}
//		return appiumService.getUrl().toString();
//	}
// public static void main(String[] args) {
//	 AppiumServer a =new AppiumServer();
//	 a.startServer();s
//	 a.stopServer();
//	 System.out.println("print " +a.getServerURL());
//}
//}
//  
