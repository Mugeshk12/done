package steps;

import org.openqa.selenium.support.PageFactory;

import base.DriverCreation;
import elements.LoginElements;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginStep extends LoginElements{
  public static LoginElements log;
	
	
	public LoginStep(AppiumDriver<MobileElement> driver) {
		super(driver);
		log =new LoginElements(DriverCreation.getDriver());
		PageFactory.initElements(new AppiumFieldDecorator(DriverCreation.getDriver()), log);	
	}
	
	// steps
	// when
	// and
	// then 
	
	
	

}
