package steps;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;

import elements.CreateTaskElement;
import elements.PageObjectManager;
import hooks.Hooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateTask extends CreateTaskElement {
	static public Logger log = Logger.getLogger(CreateTask.class);
	PageObjectManager page = new PageObjectManager();

	@When("User click on actions button")
	public void userClickOnActionsButton() {
		implicityWait(30);
		clickElement(page.getcreateTaskElement().getActionButton());
	}

	@And("User navigate to task creation page")
	public void userNavigateToTaskCreationPage() {
		implicityWait(60);
		clickElement(page.getcreateTaskElement().getCreateNewTask());
	}

	@And("Enter the action {string} text field")
	public void enterTheActionTextField(String string) {
		implicityWait(60);
		sendText(page.getcreateTaskElement().getActionTextArea(), string);
	}

	@And("Select the assignee")
	public void selectTheAssignee() {
		clickElement(page.getcreateTaskElement().getAssginee());
	}

	@And("Select the category")
	public void selectTheCategory() {
		clickElement(page.getcreateTaskElement().getCategory());
	}

	@And("Click the create button")
	public void clickTheCreateButton() {
		clickElement(page.getcreateTaskElement().getCreateTeskButton());
	}

	@Then("Verify the task create {string};")
	public void verifyTheTaskCreate(String st2) {
		String text = getText(page.getcreateTaskElement().getMessage());
		PropertyConfigurator.configure(
				"C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\src\\test\\resources\\log4j.properties");
		log.info("actual and expected value is " + text.equals(text));
	}

	@And("Click the ok button")
	public void clickTheOkButton() {
		clickElement(page.getcreateTaskElement().getOkButton());
	}

	@And("Select the high priority")
	public void selectTheHighPriority() {
		clickElement(page.getcreateTaskElement().getSelectPriority());
	}

	@And("Select the specific closure date")
	public void selectTheSpecificClosureDate() {
		clickElement(page.getcreateTaskElement().getDatePicker());
		clickElement(page.getcreateTaskElement().getClosureDate());
		clickElement(page.getcreateTaskElement().getOkButtonCalender());
	}

	@When("Select the specific closure date add after {int} day in current date")
	public void select_the_specific_closure_date_add_after_day_in_current_date(Integer int1) {
		getAddDate(int1);
	}

//	@Then("verify the task {string};")
//	public void verifyTheTask(String s1) {
//		implicityWait(10);
//		String text = getTextFromStaleElement(page.getcreateTaskElement().getTaskCheck());
//		String text = page.getcreateTaskElement().getTaskCheck().getText();
//		log.info("actual and expected value is " + text.equals(s1));
//	}

}
