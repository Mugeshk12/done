package steps;


import org.openqa.selenium.By;

import elements.CreateTaskElement;
import elements.PageObjectManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateTask extends CreateTaskElement {
	
	PageObjectManager page = new PageObjectManager();
	
	@When("User click on actions button")
	public void userClickOnActionsButton() {
		implicityWait(30);
		clickElement(page.getcreateTaskElement().getActionButton());	    
	}
	
	@And("User navigate to task creation page")
	public void userNavigateToTaskCreationPage() {
		implicityWait(60);
		clickElement(page.getcreateTaskElement().getCreateNewTask());
	}
	
	@And("enter the action {string} text field")
	public void enterTheActionTextField(String string) {
		implicityWait(60);
		sendText(page.getcreateTaskElement().getActionTextArea(), string);
	}
	
	@And("select the assignee")
	public void selectTheAssignee() {
		clickElement(page.getcreateTaskElement().getAssginee());	
	}
	
	@And("select the category")
	public void selectTheCategory() {
		clickElement(page.getcreateTaskElement().getCategory());
	}
	
	@And("click the create button")
	public void clickTheCreateButton() {
		clickElement(page.getcreateTaskElement().getCreateTeskButton());		
	}
	
	@Then("verify the task create {string};")
	public void verifyTheTaskCreate(String st2) {
		String text = getText(page.getcreateTaskElement().getMessage());
	    System.out.println(text.equals(text));
	}
	
	@And("click the ok button")
	public void clickTheOkButton() {
		clickElement(page.getcreateTaskElement().getOkButton());
	}
	
	@Then("verify the task {string};")
	public void verifyTheTask(String s1) {
		String text = page.getcreateTaskElement().getTaskCheck().getText();
		System.out.println(text.equals(s1));   
	}
	
	@And("select the high priority")
	public void selectTheHighPriority() {
	    clickElement(page.getcreateTaskElement().getSelectPriority());
	}
	@And("select the specific closure date")
	public void selectTheSpecificClosureDate() {
		clickElement(page.getcreateTaskElement().getDatePicker());
	    clickElement(page.getcreateTaskElement().getClosureDate());
	    clickElement(page.getcreateTaskElement().getOkButtonCalender());
	}

	
}
