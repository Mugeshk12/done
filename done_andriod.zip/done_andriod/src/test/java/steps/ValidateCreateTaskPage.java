package steps;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import elements.CreateTaskElement;
import elements.PageObjectManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ValidateCreateTaskPage extends CreateTaskElement{
	   static public Logger log = Logger.getLogger(ValidateCreateTaskPage.class);
	   PageObjectManager page = new PageObjectManager();

		@When("User tap on Create task + icon")
		public void user_tap_on_create_task_icon() {
			implicityWait(60);
			clickElement(page.getcreateTaskElement().getCreateNewTask());		    
		}

		@Then("Verify the validation {string} message action filed")
		public void verify_the_validation_message_action_filed(String expect) {
			String actual = getText(page.getcreateTaskElement().getActionTextArea());
			PropertyConfigurator.configure(
					"C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\src\\test\\resources\\log4j.properties");
			log.info("actual and expected value is " + actual.equals(expect));
		}
		
		@Then("{string} opens up on tap of Create task + icon")
		public void opens_up_on_tap_of_create_task_icon(String actualValue) {
			String expect = getText(page.getcreateTaskElement().getNewActionItemElement());
			PropertyConfigurator.configure(
					"C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\src\\test\\resources\\log4j.properties");
			log.info("actual and expected value is " + actualValue.equals(expect));
		}

		@Then("Tap on Create button")
		public void tap_on_create_button() {
			clickElement(page.getcreateTaskElement().getCreateTeskButton());
		}

		@Then("Verify the validation {string} message")
		public void verify_the_validation_message(String string) {
			String text = getText(page.getcreateTaskElement().getMessage());
			PropertyConfigurator.configure(
					"C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\src\\test\\resources\\log4j.properties");
			log.info("actual and expected value is " + text.equals(text));
		   
		}

		@Then("Tap on ok button")
		public void tap_on_ok_button() {
			clickElement(page.getcreateTaskElement().getOkButton());
		}

		@Then("Select the Assignee name")
		public void select_the_assignee_name() {
			clickElement(page.getcreateTaskElement().getAvinash());		    
		}
                      
		@Then("Verify the display of Assignees maximum {int}")
		public void verify_the_display_of_assignees_maximum(Integer expectSize) {
			List<?> acualSize = driver.findElements(By.xpath("(//android.view.ViewGroup[@content-desc=\"CircularImageView\"])"));
			int actualSize = acualSize.size();
			PropertyConfigurator.configure(
					"C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\src\\test\\resources\\log4j.properties");
			log.info("Verify the display of Assignees maximum : " + actualSize + " " + (actualSize > expectSize));		   
		}

		@Then("Check the display of {int} dots against the Assignee name")
		public void check_the_display_of_dots_against_the_assignee_name(Integer int1) {
			log.info("  element not present reason below 5 Assignees ");				    
		}

		@Then("Tap on {int} dots icon displaying against the Assignees name")
		public void tap_on_dots_icon_displaying_against_the_assignees_name(Integer int1) {
			log.info(" element not present ");		
		}

		@Then("Verify the opening of Assignee search window")
		public void verify_the_opening_of_assignee_search_window() {
			log.info("  element not present reason below 5 Assignees ");		    
		    }

		@Then("I should display as {string} under Assignees section")
		public void i_should_display_as_under_assignees_section(String string) {
			log.info("assignees display so not "+ string);
		   
		}

		@Then("Tap on Assignee name to select the Assignee from the task details page")
		public void tap_on_assignee_name_to_select_the_assignee_from_the_task_details_page() {
			clickElement(page.getcreateTaskElement().getAnita());
			clickElement(page.getcreateTaskElement().getAvinash());
			clickElement(page.getcreateTaskElement().getPraveen());
		}

		@Then("Tap on multiple Assignee name for selection of Assignees")
		public void tap_on_multiple_assignee_name_for_selection_of_assignees() {
			clickElement(page.getcreateTaskElement().getAnita());
			clickElement(page.getcreateTaskElement().getAvinash());
			clickElement(page.getcreateTaskElement().getPraveen());
		}

		@Then("Tap on {int} dots icon")
		public void tap_on_dots_icon(Integer int1) {
			log.info(" element not present reason below 5 Assignees ");	
		}

		@Then("Tap on Done button")
		public void tap_on_done_button() {
			clickElement(page.getcreateTaskElement().getDoneButtonCategory());
		    
		}

		@Then("Select multiple Assignees")
		public void select_multiple_assignees() {
			clickElement(page.getcreateTaskElement().getAnita());
			clickElement(page.getcreateTaskElement().getAvinash());
			clickElement(page.getcreateTaskElement().getPraveen());	    
		}

		@Then("Select Assignee name")
		public void select_assignee_name() {
			clickElement(page.getcreateTaskElement().getAvinash());
		    
		}

		@Then("Check the display of {int} dots against the category name")
		public void check_the_display_of_dots_against_the_category_name(Integer int1) {
			boolean displayed = page.getcreateTaskElement().getThreeDot().isDisplayed();
			log.info("category dot display : " + displayed);
		
		}

		@Then("Tap on {int} dots icon displaying against the category name")
		public void tap_on_dots_icon_displaying_against_the_category_name(Integer int1) {
			clickElement(page.getcreateTaskElement().getThreeDot());
		    sendText(page.getcreateTaskElement().getSearchButtonCategory(), "HR");
		}

		@Then("Select the category name")
		public void select_the_category_name() {
			clickElement(page.getcreateTaskElement().getHR());		    		
		}

		@Then("Select the Assignee")
		public void select_the_assignee() {
			clickElement(page.getcreateTaskElement().getAvinash());   
		}

		@Then("Select the Closure Date")
		public void select_the_closure_date() {		
			log.info("  select defaultr date ");
		}
		
		@Then("Select the Assignee name by searching")
		public void select_the_assignee_name_by_searching() {
			log.info("  element not present reason below 5 Assignees ");		    

		}

		@Then("Select multiple Assignees by searching")
		public void select_multiple_assignees_by_searching() {
			log.info("  element not present reason below 5 Assignees ");		    
		}

		@Then("Select the category name by searching")
		public void select_the_category_name_by_searching() {
			clickElement(page.getcreateTaskElement().getHR());
		}

		@Then("Verify the Closure Date")
		public void verify_the_closure_date() {			
			page.getcreateTaskElement().getCurrentDate().isDisplayed();	   
		}
		@Then("Verify Default Closure date i.e current date pulse {int} should display")
		public void verify_default_closure_date_i_e_current_date_pulse_should_display(Integer int1) {
			String addDate = DateTimeFormatter.ofPattern("dd MMMM yyyy")
					.format(LocalDateTime.now().plusDays(int1));
			String expect = getText(page.getcreateTaskElement().getCurrentDate());
			log.info("actual and expected value is " + addDate.equals(expect));
		}

		@Then("Tap on Calendar control to select the backdated closure Date")
		public void tap_on_calendar_control_to_select_the_backdated_closure_date() {
			clickElement(page.getcreateTaskElement().getDatePicker());
			implicityWait(30);			
			String meetingDate = DateTimeFormatter.ofPattern("dd MMMM yyyy")
					.format(LocalDateTime.now().minusDays(1));
			WebElement ele = driver.findElementByAccessibilityId(meetingDate);
			Assert.assertEquals(ele.isEnabled(), false);
			clickElement(page.getcreateTaskElement().getOkButtonCalender());
			back();
		}
		public void back() {
			driver.findElementByAccessibilityId("OnBack").click();
		}

		@Then("Verify Default Closure date i.e current date {double} {int} should display")
		public void verify_default_closure_date_i_e_current_date_should_display(Double double1, Integer int1) {
			page.getcreateTaskElement().getCurrentDate().isDisplayed();
		}
}
