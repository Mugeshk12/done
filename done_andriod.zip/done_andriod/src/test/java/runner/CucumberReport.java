package runner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import base.BaseClass;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class CucumberReport extends BaseClass{
	
	public static void cucumberReport1(String json) {
		File file = new File("C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\report\\cucumber-report");
		Configuration config = new Configuration(file,"cucumberReport");
		config.addClassifications("Tester Name", "Mugesh");
		config.addClassifications("Platform Name", "Android");
		config.addClassifications("Platform Version", "11");
		config.addClassifications("Application Name", "Done");
		//config.addClassifications("Date", "02/02/2023");
		List<String> list = new ArrayList<String>();	
		list.add(json);
		ReportBuilder reportMaking = new ReportBuilder(list, config);
		reportMaking.generateReports();		
	}
}
