package runner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import base.BaseClass;
import base.ConfigurationProperties;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class CucumberReport extends BaseClass {

	public static void cucumberReport1(String json) {
		File file = new File("C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\report\\cucumber-report");
		cp = new ConfigurationProperties();
		Configuration config = new Configuration(file, "CucumberReport");
		config.addClassifications("Tester Name", "Mugesh");
		config.addClassifications("Platform Name", cp.getPlatformName());
		config.addClassifications("Platform Version", cp.getPlatformVersion());
		config.addClassifications("Application Name", "Done");
		// config.addClassifications("Date", "02/02/2023");
		List<String> list = new ArrayList<String>();
		list.add(json);
		ReportBuilder reportMaking = new ReportBuilder(list, config);
		reportMaking.generateReports();
	}
}
