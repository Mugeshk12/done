package runner;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;

@Test()
@CucumberOptions(		
		features = {"src/test/java/features"},
		glue = {"steps","hooks"},
		//dryRun = true,
		snippets = SnippetType.CAMELCASE,
		monochrome = true,
		//tags ="@menu",
		plugin =  "//cucumber report plugin"
		)

public class RunnerTestNG extends AbstractTestNGCucumberTests{

}
