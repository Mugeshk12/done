package runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;


@RunWith(Cucumber.class)
@CucumberOptions(		
		features = {"C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\src\\test\\resources\\features\\createNewTask.feature"},
		glue = {"steps","hooks"},
	  //  dryRun = true,	
		snippets = SnippetType.CAMELCASE,
		monochrome = false,
		 //  publish = true,
		tags ="@createTask",
		plugin =  {"pretty", 
				"html:C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\report\\html-report\\report.html",
				"json:C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\report\\json-report\\jsonReport.json"		
		}
	 	)
public class RunnerJunit extends CucumberReport {
	
	@AfterClass
	public static void reportMake() {
		CucumberReport.cucumberReport1("C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\report\\json-report\\jsonReport.json");
	}
	
		
	

}
