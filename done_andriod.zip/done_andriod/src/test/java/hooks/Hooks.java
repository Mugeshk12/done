package hooks;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import base.BaseClass;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks extends BaseClass {
	static public Logger log = Logger.getLogger(Hooks.class);

	@Before
	public void beforeScenario(Scenario scenario) {
		if (driver == null) {
			driverCreation();
			implicityWait(5);
			WebElement e1 = driver.findElementByAccessibilityId("OneLabel");
			WebElement e2 = driver.findElementByAccessibilityId("OneLabel");
			WebElement e3 = driver.findElementByAccessibilityId("TwoLabel");
			WebElement e4 = driver.findElementByAccessibilityId("TwoLabel");
			clickElement(e1);
			clickElement(e2);
			clickElement(e3);
			clickElement(e4);
			implicityWait(30);
			WebElement e6 = driver.findElement(By.xpath(
					"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[3]/android.widget.Button"));
			clickElement(e6);
			WebElement e7 = driver.findElement(By
					.xpath("//android.view.ViewGroup[@content-desc=\"StackLayoutOfAccept\"]/android.widget.TextView"));
			clickElement(e7);
			PropertyConfigurator.configure(
					"C:\\Users\\mugesh.karuppaiya\\eclipse-workspace\\done_andriod\\src\\test\\resources\\log4j.properties");
			log.info("Login completed");
		}
	}

	@AfterStep
	public void failureScreenshot(Scenario scenario) {
		if (scenario.isFailed()) {
			byte[] photo = driver.getScreenshotAs(OutputType.BYTES);
			scenario.attach(photo, "image/png", "error_image");
		}
	}

//	public void setDown() {
//		stopServer();
//	}

}