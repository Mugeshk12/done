package hooks;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import base.BaseClass;
import io.appium.java_client.MobileElement;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import runner.CucumberReport;

public class Hooks extends BaseClass{
	
	
	@Before
	public void beforeScenario(Scenario scenario){
		if(driver==null) {
			driverCreation();
			// enter login details
			implicityWait(5);
			WebElement e1 = driver.findElementByAccessibilityId("OneLabel");
			WebElement e2 = driver.findElementByAccessibilityId("OneLabel");
			WebElement e3 = driver.findElementByAccessibilityId("TwoLabel");
			WebElement e4 = driver.findElementByAccessibilityId("TwoLabel");
			clickElement(e1);
			clickElement(e2);
			clickElement(e3);
			clickElement(e4);


			//System.out.println("Passcode entered...");
			// privacy policy OK btn
			
			 implicityWait(30);
			 WebElement e6 = driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[3]/android.widget.Button"));
			 clickElement(e6);
			 WebElement e7 = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"StackLayoutOfAccept\"]/android.widget.TextView"));
			 clickElement(e7);
		
			//System.out.println("I Accept btn clicked");
			System.out.println("Login completed");

		}	
	}
	
	@AfterStep
	public void failureScreenshot(Scenario scenario) {
		if(scenario.isFailed())	{
			byte[] photo = driver.getScreenshotAs(OutputType.BYTES);
			scenario.attach(photo, "image/png","error_image");			
		}
		
		}
	
	
	
//	public void setDown() {
//		stopServer();
//	}
	
}